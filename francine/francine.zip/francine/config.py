import os

# Secret key for session management
SECRET_KEY = os.environ.get('SECRET_KEY') or 'your-secret-key-here'

# MySQL configurations
MYSQL_HOST = 'localhost'
MYSQL_USER = 'root'
MYSQL_PASSWORD = 'Clemantine123'
MYSQL_DB = 'shop_ease'